<!doctype html>
<?php
	require_once '../php/Adm.class.php';
	
	if(isset($_REQUEST['acao'])){
		$acao 		= $_REQUEST['acao'];
		$name 		= $_REQUEST['login'];
		$pass 		= $_REQUEST['pass'];

		$usuario = new Usuario();
		$usuario-> login = $name;
		$usuario-> pass = $pass;
		$usuario-> idUsuario = 0;
		
		if($acao == 1)
			$usuario-> save();
		if($acao == 2)
			$usuario-> delete();
		if($acao == 3)
			$usuario-> doLogin();
	}else{
		$usuario = new Usuario();

	}
?>
<html lang="pt-br">
  <head>
    <!-- Metas -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <!-- icon fab -->
    <script src="https://kit.fontawesome.com/724af228d5.js" crossorigin="anonymous"></script>
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <!-- FAVICON -->
    <link rel="icon" href="imagens/img-pessoal/fav-login.png">
    <title>Central de Acesso </title>
  </head>

  <body style="background-color: black;">
        <!-- Menu -->
        <nav class="navbar fixed navbar-expand-lg navbar-dark " style="background-color: black;"> 
          <div class="container">
            <a class="navbar-brand" href="../tela_cadfoto/cadfoto.html">
              <img src="imagens/img-pessoal/leo-logo.png" width="150px" height="60px"> </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                  <img src="imagens/img-pessoal/id-login-menu.png" width="170px" height="60px">
              </ul>
            </div>
          </div>
        </nav> 
        <section class="jumbotron text-center" style="background-image: url(imagens/img-pessoal/port1-base.png);">
          <div class="container">
          </div>
        </section>
<!-- FIM MENU -->
<!-- Form login -->
<div class="content">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 contents text-white">
        <div class="row justify-content-center">
          <div class="col-md-12">
            <div class="form-block">
                <div class="mb-4" style="border: none;">
                <img src="imagens/img-pessoal/leo-logo.png" class="img-thumbnail">
                </div>
                <?php 
							if (isset($_REQUEST['acao'])) {
								if($usuario-> doLogin() == false) {
									echo "<span class='caption'> Usuário ou senha incorreto(a)</span>";
								}
							}                
                ?>
					
              <form style="margin-top: 20px" action="index.php" method="post">
                <div class="form-group first">
                  <label for="username">Usuário</label>
                  <input type="text" class="form-control" id="login" name="login" required>

                </div>
                <div class="form-group last mb-4">
                  <label for="senha">Senha</label>
                  <input type="password" class="form-control" id="pass" name="pass" required>
                </div>
                <input type="hidden" name="acao" value="3">
                 <input type="submit" value="Entrar" class="btn btn-pill text-white btn-block bg-secondary"> <!--colocar pra onde q vai ser enviado essas infos -->
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
<!-- FIM FORM LOGIN -->
  </body>
</html>