<?php

require_once 'DBQuery.class.php';

class Usuario {

	public $idUsuario;
	public $login;
	public $pass;

	private $tableName	= "leofotografia.adm";
	private $fields		= "idUsuario,login,pass";
	private $keyField	= "idUsuario";
	public  $dbQuery    = null;

	public function __construct($idUsuario="", $login="", $pass="") {
		$this->dbQuery = new DBQuery($this->tableName, $this->fields, $this->keyField);
		$this->setIdUsuario($idUsuario);
		$this->setLogin		($login);
		$this->setPass		($pass);
	}

	public function __construct1($login, $pass) {
		$this->dbQuery = new DBQuery($this->tableName, $this->fields, $this->keyField);
		$this->setIdUsuario($idUsuario);
		$this->setLogin($login);
		$this->setPass($pass);
	}

	public function __construct2() {
		$this->dbQuery = new DBQuery($this->tableName, $this->fields, $this->keyField);
	}

    public function getIdUsuario(){
        return $this->idUsuario;
    }

    public function setIdUsuario($idUsuario){
        $this->idUsuario = $idUsuario;
    }

    public function getLogin(){
        return $this->login;
    }

    public function setLogin($login){
        $this->login = $login;
    }

    public function getPass(){
        return $this->pass;
    }

    public function setPass($pass){
        $this->pass = $pass;
    }

   	public function toArray() {
   		return(
   			array(
   					$this->idUsuario,
   					$this->login,
   					$this->pass,
   				)
   			);
   	}

   	public function doLogin() {
			// Impede SQL Injection


			 echo "Atenção:";
			// Realiza a consulta do usuário
			//$sql = "SELECT nusuaario, user, senha FROM dados WHERE user = '".$user."' and senha = '".$pass."'";
			//$resultados = query($sql);
			$resultados = $this->dbQuery->select("login='".$this-> login."'  AND pass='".$this-> pass."'", "", "")	;

			if ($count=mysqli_num_rows($resultados)){
				$linha=mysqli_fetch_assoc($resultados);
				session_start();
				$_SESSION['idAdm']  = $linha['idUsuario'];
				//echo $_SESSION['idUsuario'];
				setcookie('idAdm', $_SESSION['idAdm'] ,time()+(60*15)); // 15 min
				//echo $_COOKIE['idUsuario'];
				header("Location: ../tela_admgeral/mfadm.php");
				return true;
			}else{

				setcookie('idAdm', 'fail' ,time()+(60*15)); // 15 min

  			 	return false;
  			}
	}

	public function checkLogin() {
		session_start();
		if (isset($_SESSION['idAdm'])){
			return true;
		} else {
		   return false;
		}
}

		public function checkLoginRedirect() {
		//session_start();
		if (!$this->checkLogin()){
			header("Location: ../adm/index.php");
		}
	}
   	
   	public function logOut() {
				session_start();
				session_destroy( $_COOKIE['idAdm']);
				unset ( $_SESSION['idAdm']);
				header("Location: adm/index.php");
		}
}

?>
