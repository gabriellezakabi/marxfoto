<?php

require_once 'DBConnection.class.php';

class DBQuery {
	
	private $tableName; 
	private $fields;
	private $fields2;
	private $keyField;
	
	public function __construct($tableName, $fields, $keyField) {
		$this->setTableName		($tableName);
		$this->setFields		($fields);
		$this->setKeyField		($keyField);
	}

	public function select($where) {
		$sql = "";
		$sql .= " SELECT "	. implode(", ", $this->getFields());
		$sql .= " FROM "	. $this->getTableName();
		$sql .= (($where!="")?(" WHERE ".$where):"");
		$dbConnection = new DBConnection();
		$resultSet = $dbConnection->query($sql);
		return ($resultSet);
	}
	
		public function selectmax() {
		$sql = "";
		$sql .= " SELECT max((idProduto)+1) " ;
		$sql .= " AS idmax " ;
		$sql .= " FROM "	. $this->getTableName();

		
		$dbConnection = new DBConnection();
		$resultSet = $dbConnection->query($sql);
		
		return mysqli_fetch_assoc($resultSet);
	}
	
	function insert($values) {
		$sql  = "";
		$sql .= "  INSERT INTO ". $this->getTableName();
		$sql .= " ( ". implode(", ", $this->getFields()).")";
		$sql .= " VALUES ('". implode("','", $values) ."')";
		$dbConnection = new DBConnection();
		
		$resultSet = $dbConnection->query($sql);
		return ($resultSet);
	}	
	

	function delete($keyValue) {
	
		if($keyValue!=""){
			$sql = " DELETE FROM ". $this->getTableName();
			$sql .=" WHERE ".$this->keyField."= '".$keyValue."'";
			
			$dbConnection = new DBConnection();
			$resultSet = $dbConnection->query($sql);
			return ($resultSet);
		}else{
			return (0);
		}
	}
	
	
	function update($values) {
		
		$qtd = count($values);
		$arrayFields = $this->getFields();
		
		$sql  = " UPDATE ". $this->getTableName();
		$sql .= " SET ";
		for($i=1; $i<$qtd; $i++){   // $i++ == $i=$i+1
			$sql .= " ".$arrayFields[$i]."= '".$values[$i]."' ";
			$sql .=  ($i==$qtd-1)?" ":",";
		}
		$sql .=" WHERE ".$this->getKeyField()."= '".$values[0]."'";
		
		$dbConnection = new DBConnection();
		$resultSet = $dbConnection->query($sql);
		return ($resultSet);
	}

    public function getTableName(){
        return $this->tableName;
    }

    public function setTableName($tableName){
        $this->tableName = $tableName;
    }

    public function getFields(){
        return $this->fields;
    }

    public function setFields($fields){
    	$fields = str_replace(" ", "", $fields);
    	$arrayFields = explode(",", $fields);
        $this->fields = $arrayFields;
    }
    
    public function getFields2(){
        return $this->fields2;
    }

    public function setFields2($fields2){
    	$fields = str_replace(" ", "", $fields2);
    	$arrayFields = explode(",", $fields2);
        $this->fields2 = $arrayFields;
    }

    public function getKeyField(){
        return $this->keyField;
    }

    public function setKeyField($keyField){
        $this->keyField = $keyField;
    }
	
    public function getDbConnection(){
    	$dbConnection = new DBConnection();
    	return ($dbConnection);
    }

}

?>