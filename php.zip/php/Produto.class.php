<?php

require_once 'DBQuery.class.php';

class Produto {

		public  $idProduto;
		public  $idProduto2;
		public $pagina 	;
		public $nome 	;
		public $categoria;
		public $imagem;

	private $tableName	= "leofotografia.produto";
	private $fields		= "idProduto,nome,categoria,imagem";
	private $keyField	= "idProduto";
	public  $dbQuery    = null;

	public function __construct($idProduto="", $nome="", $categoria="" ) {
		$this->dbQuery = new DBQuery($this->tableName, $this->fields, $this->keyField);
		$this->setIdProduto($idProduto);
		$this->setNome		($nome);
		$this->setCategoria		($categoria);
	}
	
	public function __construct2() {
		$this->dbQuery = new DBQuery($this->tableName, $this->fields, $this->keyField);
	}
	
	
	public function getIdProduto(){
		return $this->idProduto;
	}


	public function setIdProduto($idProduto){
		$this->idProduto = $idProduto;
		return $this;
	}


	public function getNome(){
		return $this->nome;
	}


	public function setNome($nome){
		$this->nome = $nome;
		return $this;
	}

	public function getCategoria(){
		return $this->categoria;
	}



	public function setCategoria($categoria){
		$this->categoria = $categoria;
		return $this;
	}


	public function getImagem(){
		return $this->imagem;
	}


	public function setImagem($imagem){
		$this->imagem = $imagem;
		return $this;
	}


		public function toArray() {
			return(
				array(
								$this->idProduto,
		$this->nome 	,
		$this->categoria,
		$this->imagem,
		
					)
				);
		}

		public function save() {
			if ($this->idProduto > 0 ){
				$this->dbQuery->update($this->toArray());

			}else{
				$this->dbQuery->insert($this->toArray());

			}
		}

		public function delete() {
			$this->dbQuery->delete($this-> idProduto);
		}

		public function selectmaxid() {

			$linha =	$this->dbQuery->selectmax();
			
			$out = " <input id='Nome' name='idProduto2' value='".$linha["idmax"]."' placeholder='' class='form-control input-md' required='' type='hidden'>";
			return ($out);
				}

		
		public function getProduto($id) {

			$resultSet = $this->dbQuery->select("idProduto = '".$id."'"); 
			
			while ($linha = mysqli_fetch_array($resultSet)) { 
				$this-> nome = $linha['nome'];
				$this-> categoria = $linha['categoria'];
				$this-> imagem = $linha['imagem'];
			}
		}
		
		public function editForm($id) {
			$out = "";
			
			$out .= "<form action='editfoto.php' enctype='multipart/form-data' method='post'> " ;
			$out .= "                      <div class='form-group first'> " ;
			$out .= "                        <label for='titulo'>Título:</label> " ;
			$out .= "                        <input type='text' value='".$this->nome."' name='nome' class='form-control' id='titulo' required> " ;
			$out .= "                      </div> " ;
			$out .= "                      <div class='form-group last mb-4'> " ;
			$out .= "                        <label for='exampleFormControlSelect1'>Tipo de ensaio:</label> " ;
			$out .= "                        <select name='categoria' class='form-control' id='ensaio'> " ;
			if ($this-> categoria == 'Ensaio Feminino') {
			  $out .= "                          <option selected>Ensaio Feminino</option> " ;
			} else {
			  $out .= "                          <option>Ensaio Feminino</option> " ;
			}
			if ($this-> categoria == 'Ensaio Masculino') {
			  $out .= "                          <option selected>Ensaio Masculino</option> " ;
			} else {
			  $out .= "                          <option>Ensaio Masculino</option> " ;
			} 
			if ($this-> categoria == 'Ensaio Casal') {
			  $out .= "                          <option selected>Ensaio Casal</option> " ;
			} else {
			  $out .= "                          <option>Ensaio Casal</option> " ;
			} 
			if ($this-> categoria == 'Evento') {
			  $out .= "                          <option selected>Evento </option> " ;
			} else {
			  $out .= "                          <option>Evento </option> " ;
			}
			if ($this-> categoria == 'Ensaio Infantil') {
			  			$out .= "                          <option selected>Ensaio Infantil</option> " ;
			} else {
			  			$out .= "                          <option>Ensaio Infantil</option> " ;
			}
			$out .= "                        </select> " ;
			$out .= "                      </div> " ;             
		   $out .= "                       <input name='idProduto' type='hidden' value='".$id."'> " ; 
		   $out .= "                       <input name='imagem' type='hidden' value='".$this-> imagem."'> " ; 
		   $out .= "                       <input name='acao' type='hidden' value='1'> " ; 
			$out .= "                       <input type='submit' value='Editar' class='btn btn-pill text-white btn-block bg-secondary'> " ; 
			$out .= "                    </form> " ;		
			return $out;
		} 


		public function viewProdutos() {

   	
			$resultSet = $this->dbQuery->select("");
			$out= "";
   		
			while ($linha = mysqli_fetch_array($resultSet)) {
   			
					$out .= "<figure class='col-md-4'> " ;
					$out .= "          <a href='".$linha['imagem']."' data-size='1600x1067'> " ;
					$out .= "           <img alt='picture' src='".$linha['imagem']."' class='img-fluid'> " ;
					$out .= "         </a> " ;
					$out .= "        </figure> " ;
			};
			return($out);
		}
   	
		public function viewProdutosList() {

   	
			$resultSet = $this->dbQuery->select("");
			$out= "";
   		
			while ($linha = mysqli_fetch_array($resultSet)) {
   			
					$out .= "<div class='row'> " ;
					$out .= "<div class='col text-center'>".$linha['nome']."</div> " ;
					$out .= "<div class='col text-center'>".$linha['categoria']."</div> " ;
					$out .= "<div class='col text-center'>".$linha['imagem']."</div> " ; 
					$out .= "<div class='col text-center'><a href='../tela_editcad/editfoto.php?idProduto=".$linha['idProduto']."'><img src='../imagens/img-pessoal/editar.png' width='20px' height='20px'/></a></div> " ;
					$out .= "<div class='col text-center'><a href='mfadm.php?acao=2&idProduto=".$linha['idProduto']."'><img src='../imagens/img-pessoal/delete.png' width='20px' height='20px'/></a></div> " ;		
					$out .= "</div> " ;
			};
			return($out);
		
		
				
	}


	}

?>
