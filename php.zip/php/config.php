<?php

	   $db_host     = 'localhost';
	   $db_username = 'root';
	   $db_port 	= '3306';
		$db_password = '';
	   $db_schema   = 'leofotografia';
	   $db_charset  = 'utf8';
				
?>