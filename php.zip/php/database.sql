CREATE DATABASE leofotografia CHARSET utf8;

use leofotografia;

CREATE TABLE `adm` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) NOT NULL DEFAULT '',
  `pass` varchar(64) NOT NULL DEFAULT '',
  
  PRIMARY KEY (`idUsuario`)
);

CREATE TABLE `produto` (
  `idProduto` int(11) NOT NULL AUTO_INCREMENT,
  `imagem` varchar(100) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  PRIMARY KEY (`idProduto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


insert into leofotografia.adm values (1, "admin", "admin@123")