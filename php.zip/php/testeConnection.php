<?php

	require_once 'DBConnection.class.php';
	
	$dbConnection = new DBConnection();
	$rs = $dbConnection->query("SELECT idUsuario,login,pass,email,nivel,ativo FROM lpi.usuarios;");

	echo "<hr>";
	while ($linha = mysqli_fetch_array($rs)) {
		print_r($linha);
		echo "<hr>";
	}
	
	
?>