<?php 

require_once '../php/Produto.class.php';
$produto = new Produto();

?>


<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>Portfólio</title>

    <!-- Metas -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Fotografia, ensaios fotográficos em São Paulo">
    <meta name="keywords" content="Fotografia, São Paulo, Ensaio feminino, Ensaio masculino, Ensaio infaltil, Guarulhos, Eventos, modelo, canon">
    <meta name="author" content="GGLWeb" >
    <meta property="og:title" content="Orçamento fotográfico Marx Fotografias">
    <meta property="og:description" content="Confira nossos pacotes fotográficos e faça um orçamento!">
    <meta property="og:image" content="imagens/leo-logo.png">

    <!-- Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <!-- icon fab -->
    <script src="https://kit.fontawesome.com/724af228d5.js" crossorigin="anonymous"></script>
    
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="css/index.css">

    <!-- FAVICON -->
    <link rel="icon" href="imagens/img-pessoal/leo-id.jpeg"> 

  </head>

  <body>
        <!-- Menu -->
        <nav class="navbar fixed navbar-expand-lg navbar-dark " style="background-color: black;"> 
          <div class="container">
            <a class="navbar-brand" href="../index.html">
              <img src="imagens/img-pessoal/leo-logo.png" width="150px" height="60px"> 
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
            </div>
          </div>
        </nav> <!-- FIM MENU -->

<main role="main">

  <section class="jumbotron text-center" style="background-image: url(imagens/img-pessoal/port1-base.png);">
    <div class="container">
    </div>
  </section>

<div class="container">  <!--  exemplificação do modelo que deve ser empregado na programação php, na listagem de cadastramento do banco de dados, as fotos cadastradas -->
  <div class="row">    
        <?php echo $produto-> viewProdutos() ?>
  </div>
</div> 
 
</main>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
</script>
<script>window.jQuery || document.write('<script src="/docs/4.5/assets/js/vendor/jquery.slim.min.js"><\/script>')</script>
<script src="/docs/4.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
</script>

<footer class="page-footer font-small pt-4" style="background-color: black;">
  <div class="container">
    <p class="float-right">
      <a href="#">Voltar ao topo</a> </p>
  </div>
  <div class="footer-copyright text-left py-3">© 2020 Copyright:
    <a href="#home"> Marx Fotografias</a>
  </div>
</footer>


</body>
</html>